
(function () {
    if (typeof window.jsb === 'object') {
        var hotUpdateSearchPaths = localStorage.getItem('HotUpdateSearchPaths');
        if (hotUpdateSearchPaths) {
            var paths = JSON.parse(hotUpdateSearchPaths);
            jsb.fileUtils.setSearchPaths(paths);

            var fileList = [];
            var storagePath = paths[0] || '';
            var tempPath = storagePath + '_temp/';
            var baseOffset = tempPath.length;

            if (jsb.fileUtils.isDirectoryExist(tempPath) && !jsb.fileUtils.isFileExist(tempPath + 'project.manifest.temp')) {
                jsb.fileUtils.listFilesRecursively(tempPath, fileList);
                fileList.forEach(srcPath => {
                    var relativePath = srcPath.substr(baseOffset);
                    var dstPath = storagePath + relativePath;

                    if (srcPath[srcPath.length] == '/') {
                        cc.fileUtils.createDirectory(dstPath)
                    }
                    else {
                        if (cc.fileUtils.isFileExist(dstPath)) {
                            cc.fileUtils.removeFile(dstPath)
                        }
                        cc.fileUtils.renameFile(srcPath, dstPath);
                    }
                })
                cc.fileUtils.removeDirectory(tempPath);
            }
        }
    }
})();

(function () {
    if (typeof window.jsb === 'object') {
        var hotUpdateSearchPaths = localStorage.getItem('HotUpdateSearchPaths');
        if (hotUpdateSearchPaths) {
            var paths = JSON.parse(hotUpdateSearchPaths);
            jsb.fileUtils.setSearchPaths(paths);

            // Xử lý file còn dở trong _temp (app bị kill giữa chừng update)
            // QUAN TRỌNG: dùng jsb.fileUtils (không phải cc.fileUtils - cc chưa tồn tại ở đây)
            var fileList = [];
            var storagePath = (paths[0] || '').replace(/\/$/, '');
            var tempPath = storagePath + '_temp/';
            var baseOffset = tempPath.length;

            if (jsb.fileUtils.isDirectoryExist(tempPath) && !jsb.fileUtils.isFileExist(tempPath + 'project.manifest.temp')) {
                jsb.fileUtils.listFilesRecursively(tempPath, fileList);
                fileList.forEach(function(srcFilePath) {
                    var relativePath = srcFilePath.substr(baseOffset);
                    var dstPath = storagePath + relativePath;
                    // srcFilePath[srcFilePath.length - 1] mới đúng (length là out-of-bounds)
                    if (srcFilePath[srcFilePath.length - 1] === '/') {
                        jsb.fileUtils.createDirectory(dstPath);
                    } else {
                        if (jsb.fileUtils.isFileExist(dstPath)) {
                            jsb.fileUtils.removeFile(dstPath);
                        }
                        jsb.fileUtils.renameFile(srcFilePath, dstPath);
                    }
                });
                jsb.fileUtils.removeDirectory(tempPath);
            }
            
            // Xoá cache của settings.js nếu cần thiết trong jsb
            // Require cache trong C++ có thể giữ bản cũ
            if (typeof require !== 'undefined' && require.cache) {
                for (var key in require.cache) {
                    if (key.indexOf('src/settings.js') !== -1 || 
                        key.indexOf('main.js') !== -1 ||
                        key.indexOf('src/cocos2d-jsb.js') !== -1 ||
                        key.indexOf('jsb-adapter/jsb-engine.js') !== -1) {
                        delete require.cache[key];
                    }
                }
            }
        }
    }
})();
window.boot = function () {
    // Restore hot update search paths trước khi load bất kỳ bundle nào.
    // cc.game.restart() reset JS state → gọi lại boot() mà không chạy lại IIFE.
    // Phải restore ở đây để đảm bảo cả cold-start lẫn soft-restart đều đúng.
    if (typeof jsb !== 'undefined' && jsb.fileUtils) {
        try {
            var _husp = localStorage.getItem('HotUpdateSearchPaths');
            if (_husp) {
                var _paths = JSON.parse(_husp);
                // Chỉ apply nếu thư mục hot-update thực sự tồn tại trên thiết bị
                var _sp = (_paths[0] || '').replace(/\/$/, '');
                if (_sp && jsb.fileUtils.isDirectoryExist(_sp)) {
                    jsb.fileUtils.setSearchPaths(_paths);
                    console.log('[boot] HotUpdate searchPaths applied: ' + _paths[0]);
                } else {
                    // Storage bị xóa/mất → clear localStorage để force re-download
                    console.log('[boot] HotUpdate storage missing (' + _sp + '), clearing saved paths.');
                    localStorage.removeItem('HotUpdateSearchPaths');
                    localStorage.removeItem('HotUpdateLastVersion');
                }
            }
        } catch (_e) {
            console.log('[boot] HotUpdate searchPaths error: ' + _e);
        }
    }
    var settings = window._CCSettings;
    window._CCSettings = undefined;
    var onProgress = null;
    
    var RESOURCES = cc.AssetManager.BuiltinBundleName.RESOURCES;
    var INTERNAL = cc.AssetManager.BuiltinBundleName.INTERNAL;
    var MAIN = cc.AssetManager.BuiltinBundleName.MAIN;
    function setLoadingDisplay () {
        // Loading splash scene
        var splash = document.getElementById('splash');
        var progressBar = splash.querySelector('.progress-bar span');
        onProgress = function (finish, total) {
            var percent = 100 * finish / total;
            if (progressBar) {
                progressBar.style.width = percent.toFixed(2) + '%';
            }
        };
        splash.style.display = 'block';
        progressBar.style.width = '0%';

        cc.director.once(cc.Director.EVENT_AFTER_SCENE_LAUNCH, function () {
            splash.style.display = 'none';
        });
    }

    var onStart = function () {

        cc.view.enableRetina(true);
        cc.view.resizeWithBrowserSize(true);

        if (cc.sys.isBrowser) {
            setLoadingDisplay();
        }

        if (cc.sys.isMobile) {
            if (settings.orientation === 'landscape') {
                cc.view.setOrientation(cc.macro.ORIENTATION_LANDSCAPE);
            }
            else if (settings.orientation === 'portrait') {
                cc.view.setOrientation(cc.macro.ORIENTATION_PORTRAIT);
            }
            cc.view.enableAutoFullScreen([
                cc.sys.BROWSER_TYPE_BAIDU,
                cc.sys.BROWSER_TYPE_BAIDU_APP,
                cc.sys.BROWSER_TYPE_WECHAT,
                cc.sys.BROWSER_TYPE_MOBILE_QQ,
                cc.sys.BROWSER_TYPE_MIUI,
                cc.sys.BROWSER_TYPE_HUAWEI,
                cc.sys.BROWSER_TYPE_UC,
            ].indexOf(cc.sys.browserType) < 0);
        }

        // Limit downloading max concurrent task to 2,
        // more tasks simultaneously may cause performance draw back on some android system / browsers.
        // You can adjust the number based on your own test result, you have to set it before any loading process to take effect.
        if (cc.sys.isBrowser && cc.sys.os === cc.sys.OS_ANDROID) {
            cc.assetManager.downloader.maxConcurrency = 2;
            cc.assetManager.downloader.maxRequestsPerFrame = 2;
        }

        var launchScene = settings.launchScene;
        var bundle = cc.assetManager.bundles.find(function (b) {
            return b.getSceneInfo(launchScene);
        });
        
        bundle.loadScene(launchScene, null, onProgress,
            function (err, scene) {
                if (!err) {
                    cc.director.runSceneImmediate(scene);
                    if (cc.sys.isBrowser) {
                        // show canvas
                        var canvas = document.getElementById('GameCanvas');
                        canvas.style.visibility = '';
                        var div = document.getElementById('GameDiv');
                        if (div) {
                            div.style.backgroundImage = '';
                        }
                        console.log('Success to load scene: ' + launchScene);
                    }
                }
            }
        );

    };

    var option = {
        id: 'GameCanvas',
        debugMode: settings.debug ? cc.debug.DebugMode.INFO : cc.debug.DebugMode.ERROR,
        showFPS: settings.debug,
        frameRate: 60,
        groupList: settings.groupList,
        collisionMatrix: settings.collisionMatrix,
    };

    cc.assetManager.init({ 
        bundleVers: settings.bundleVers,
        remoteBundles: settings.remoteBundles,
        server: settings.server
    });
    
    // override remoteBundles version to force reload if needed
    // AssetManager sẽ luôn check cache dựa vào path vật lý trước, trừ khi bị clean
    
        var bundleRoot = [INTERNAL];
        settings.hasResourcesBundle && bundleRoot.push(RESOURCES);

        var count = 0;
    var cb = function (err) {
        if (err) return console.error(err.message, err.stack);
        count++;
        if (count === bundleRoot.length + 1) {
            cc.assetManager.loadBundle(MAIN, function (err) {
                if (!err) cc.game.run(option, onStart);
            });
        }
    };

    // Load settings.js from hot update path first if available
    var jsList = settings.jsList;
    var bundledJsList = jsList.map(function (x) { return 'src/' + x;});
    
    // Add custom version for main bundle when loading to ignore cache if needed
    var mainBundleVers = settings.bundleVers ? settings.bundleVers[MAIN] : '';
    if (mainBundleVers) {
        cc.assetManager.downloader.bundleVers = cc.assetManager.downloader.bundleVers || {};
        cc.assetManager.downloader.bundleVers[MAIN] = mainBundleVers;
    }

    cc.assetManager.loadScript(bundledJsList, cb);

    for (var i = 0; i < bundleRoot.length; i++) {
        cc.assetManager.loadBundle(bundleRoot[i], cb);
    }
};

if (window.jsb) {
    var isRuntime = (typeof loadRuntime === 'function');
    if (isRuntime) {
        require('src/settings.js');
        require('src/cocos2d-runtime.js');
        if (CC_PHYSICS_BUILTIN || CC_PHYSICS_CANNON) {
            require('src/physics.js');
        }
        require('jsb-adapter/engine/index.js');
    }
    else {
        require('src/settings.js');
        require('src/cocos2d-jsb.js');
        if (CC_PHYSICS_BUILTIN || CC_PHYSICS_CANNON) {
            require('src/physics.js');
        }
        require('jsb-adapter/jsb-engine.js');
    }

    cc.macro.CLEANUP_IMAGE_CACHE = true;
    window.boot();
}